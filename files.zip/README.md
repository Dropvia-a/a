# My Shop

A static online shop you can host free on GitHub Pages. No server, no build step.

## 1. Add your products
Open `products.js`:
- Change the `SHOP` block (name, your email, currency).
- Edit or copy the entries in `PRODUCTS`.
- Put product photos in the `images/` folder and match the file names in `image:`.
  Square photos around 1000x1000 px look best. Leave `image: ""` for a grey numbered placeholder.

## 2. Put it on GitHub
1. Create a new repository on github.com (public).
2. Upload `index.html`, `products.js`, `README.md` and the `images` folder
   (**Add file → Upload files**, drag them in, then **Commit changes**).
3. Go to **Settings → Pages**. Under **Branch**, choose `main` and `/ (root)`, then **Save**.
4. After a minute your shop is live at `https://YOUR-USERNAME.github.io/REPO-NAME/`.

To update the shop later, edit `products.js` on GitHub (pencil icon) and commit.

## 3. How customers pay
GitHub Pages can't process cards itself, so this shop supports two options:

- **Cart + email order (default):** the customer fills their cart, clicks *Send order by email*,
  and you reply with a total and payment details (bank transfer, PayPal invoice, etc.).
- **Buy now button:** create a Payment Link in Stripe, PayPal, or Square for an item and paste it
  into that product's `buyLink`. Customers pay on the provider's secure page.

Never put secret API keys in these files. Payment Links are safe because they are just public URLs.
