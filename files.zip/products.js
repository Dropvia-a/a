// ============================================================
//  EDIT THIS FILE to change your shop. No other file needs touching.
// ============================================================

const SHOP = {
  name: "yourshop",
  email: "you@example.com",   // cart orders are emailed to this address
  currency: "AUD",
  locale: "en-AU",
  shipping: "Free delivery on orders over $50. I'll confirm the final total and payment details by email."
};

// image: path to a photo in images/ ("" shows a grey placeholder)
// oldPrice: optional, shows a crossed-out price and a % off badge
// buyLink: optional Stripe / PayPal / Square payment link, adds a "Buy Now" button
const PRODUCTS = [
  { id:"1",  name:"Product 1",  price:19.99,  oldPrice:29.99,  rating:4.5, reviews:1284, category:"Category A", image:"", description:"Placeholder description for Product 1.",  buyLink:"", soldOut:false },
  { id:"2",  name:"Product 2",  price:34.50,  oldPrice:0,      rating:4.0, reviews:312,  category:"Category A", image:"", description:"Placeholder description for Product 2.",  buyLink:"", soldOut:false },
  { id:"3",  name:"Product 3",  price:12.00,  oldPrice:15.00,  rating:3.5, reviews:87,   category:"Category B", image:"", description:"Placeholder description for Product 3.",  buyLink:"", soldOut:false },
  { id:"4",  name:"Product 4",  price:89.95,  oldPrice:119.95, rating:5.0, reviews:2045, category:"Category B", image:"", description:"Placeholder description for Product 4.",  buyLink:"", soldOut:false },
  { id:"5",  name:"Product 5",  price:7.49,   oldPrice:0,      rating:4.5, reviews:640,  category:"Category C", image:"", description:"Placeholder description for Product 5.",  buyLink:"", soldOut:false },
  { id:"6",  name:"Product 6",  price:45.00,  oldPrice:60.00,  rating:4.0, reviews:158,  category:"Category C", image:"", description:"Placeholder description for Product 6.",  buyLink:"", soldOut:false },
  { id:"7",  name:"Product 7",  price:129.00, oldPrice:0,      rating:4.5, reviews:903,  category:"Category D", image:"", description:"Placeholder description for Product 7.",  buyLink:"", soldOut:false },
  { id:"8",  name:"Product 8",  price:22.80,  oldPrice:28.00,  rating:3.0, reviews:41,   category:"Category D", image:"", description:"Placeholder description for Product 8.",  buyLink:"", soldOut:true  },
  { id:"9",  name:"Product 9",  price:58.00,  oldPrice:0,      rating:4.5, reviews:520,  category:"Category A", image:"", description:"Placeholder description for Product 9.",  buyLink:"", soldOut:false },
  { id:"10", name:"Product 10", price:16.25,  oldPrice:20.00,  rating:4.0, reviews:276,  category:"Category B", image:"", description:"Placeholder description for Product 10.", buyLink:"", soldOut:false },
  { id:"11", name:"Product 11", price:74.99,  oldPrice:99.99,  rating:5.0, reviews:1730, category:"Category C", image:"", description:"Placeholder description for Product 11.", buyLink:"", soldOut:false },
  { id:"12", name:"Product 12", price:9.99,   oldPrice:0,      rating:3.5, reviews:64,   category:"Category D", image:"", description:"Placeholder description for Product 12.", buyLink:"", soldOut:false }
];
